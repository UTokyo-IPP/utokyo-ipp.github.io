a1 = 10
print('a1 contains the value of', a1)
